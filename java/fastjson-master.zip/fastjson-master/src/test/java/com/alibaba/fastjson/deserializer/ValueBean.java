package com.alibaba.fastjson.deserializer;

/**
 * Created by jiangyu on 2017-03-03 11:34.
 */
public class ValueBean {

    private Integer val;

    public Integer getVal() {
        return val;
    }

    public ValueBean setVal(Integer val) {
        this.val = val;
        return this;
    }
}
