package com.alibaba.json.bvtVO.vip_com;

import java.math.BigDecimal;

public class TxnListItsm {
  private String assets_no;
  private BigDecimal cover_vol;
  
  public String getAssets_no() {
    return assets_no;
  }

  public void setAssets_no(String assets_no) {
    this.assets_no = assets_no;
  }

  public BigDecimal getCover_vol() {
    return cover_vol;
  }

  public void setCover_vol(BigDecimal cover_vol) {
    this.cover_vol = cover_vol;
  }
  
}