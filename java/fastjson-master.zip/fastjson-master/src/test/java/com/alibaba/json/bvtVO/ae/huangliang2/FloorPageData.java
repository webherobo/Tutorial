package com.alibaba.json.bvtVO.ae.huangliang2;

import java.util.List;

/**
 * Created by huangliang on 17/5/8.
 */

public class FloorPageData {
    public List<Area> areas;
}
