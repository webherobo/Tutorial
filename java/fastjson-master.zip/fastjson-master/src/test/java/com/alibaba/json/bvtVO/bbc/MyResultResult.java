package com.alibaba.json.bvtVO.bbc;


public class MyResultResult extends BaseResult<String> {

    public MyResultResult(){

    }
}
