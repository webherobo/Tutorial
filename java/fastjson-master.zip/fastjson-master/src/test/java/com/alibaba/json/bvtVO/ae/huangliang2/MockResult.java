package com.alibaba.json.bvtVO.ae.huangliang2;

import com.alibaba.fastjson.JSONObject;

/**
 * Created by huangliang on 17/5/9.
 */

public class MockResult {
    boolean isTest;
    public JSONObject mockResult;
}
