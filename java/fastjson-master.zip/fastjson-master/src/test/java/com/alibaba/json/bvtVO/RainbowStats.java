package com.alibaba.json.bvtVO;

public class RainbowStats {
	private int id;
	private String name;

	public int getId() {
		return id;
	}

	public RainbowStats setId(int id) {
		this.id = id;
		return this;
	}

	public String getName() {
		return name;
	}

	public RainbowStats setName(String name) {
		this.name = name;
		return this;
	}

}
