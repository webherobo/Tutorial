package com.alibaba.json.bvtVO.ae;

public class Item implements Area {
    public String name;

    public String getName() {
        return name;
    }
}
