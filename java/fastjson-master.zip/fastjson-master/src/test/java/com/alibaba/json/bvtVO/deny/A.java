package com.alibaba.json.bvtVO.deny;


public class A {

}
