package com.alibaba.json.bvtVO.ae;

import java.util.List;

/**
 * Created by wenshao on 09/05/2017.
 */
public class Data {
    public List<Area> areaList;
}
