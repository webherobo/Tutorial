package com.alibaba.json.bvtVO.ae;

import com.alibaba.fastjson.annotation.JSONType;

/**
 * Created by huangliang on 17/4/12.
 */
public interface Area {
    public static final String TYPE_FLOOR = "floor";
    public static final String TYPE_ITEM = "item";

    String getName();
}
