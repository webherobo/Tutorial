package com.alibaba.json.bvtVO.ae.huangliang2;


import com.alibaba.fastjson.annotation.JSONType;

/**
 * Created by huangliang on 17/5/8.
 */

public interface Floor extends Area {

}
