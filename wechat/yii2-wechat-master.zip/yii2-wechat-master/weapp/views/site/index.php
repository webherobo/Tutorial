<?php

/* @var $this yii\web\View */

$this->title = '邻时科技';
?>
<div class="site-index">

    <div class="jumbotron">
        <h3>...</h3>
    </div>

</div>