<?php

/* @var $this yii\web\View */

$this->title = 'xxx';
?>
<div class="site-index">

    <div class="jumbotron">
        <h3>...</h3>
    </div>

</div>