# dateTimePicker
**微信小程序 自定义日期时间选择器**<br/>
项目需要，花了一个小时去写这个日期时间选择器，上效果图~<hr />

## 效果图
<p>
<img src="https://github.com/shuangjie/dateTimePicker/blob/master/images/effect/1.PNG" width="400px">
<img src="https://github.com/shuangjie/dateTimePicker/blob/master/images/effect//2.PNG" width="400px">
</p>
<p>
<img src="https://github.com/shuangjie/dateTimePicker/blob/master/images/effect/3.PNG" width="400px">
<img src="https://github.com/shuangjie/dateTimePicker/blob/master/images/effect/dateTimePicker_effect.gif" width="400px">
</p>

_如果觉得对你还有些帮助，顺手点一下`star`吧 (｡♥‿♥｡)_
